from django.apps import AppConfig


class RegulationsConfig(AppConfig):
    name = 'partner'
