from django.apps import AppConfig


class MainClientConfig(AppConfig):
    name = 'main_client'
