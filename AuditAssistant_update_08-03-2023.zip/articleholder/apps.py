from django.apps import AppConfig


class ArticleholderConfig(AppConfig):
    name = 'articleholder'
